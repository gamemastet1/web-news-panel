<div class="bg-dark border-right" id="sidebar-wrapper">
    <div class="sidebar-heading text-white">پنل مدیریت</div>
    <div class="list-group list-group-flush">
        <a href="index.php" class="list-group-item list-group-item-action bg-dark text-white">خانه</a>
        <a href="manage-news.php" class="list-group-item list-group-item-action bg-dark text-white">مدیریت اخبار</a>
        <a href="manage-comments.php" class="list-group-item list-group-item-action bg-dark text-white">مدیریت نظرات</a>
        <a href="manage-users.php" class="list-group-item list-group-item-action bg-dark text-white">مدیریت کاربران</a>
        <a href="manage-categories.php" class="list-group-item list-group-item-action bg-dark text-white">مدیریت دسته‌بندی‌ها</a>
        <a href="manage-tags.php" class="list-group-item list-group-item-action bg-dark text-white">مدیریت تگ‌ها</a>
        <a href="manage-ads.php" class="list-group-item list-group-item-action bg-dark text-white">مدیریت تبلیغات</a>
        <a href="reports.php" class="list-group-item list-group-item-action bg-dark text-white">گزارش‌ها و آمار</a>
        <a href="notifications.php" class="list-group-item list-group-item-action bg-dark text-white">سیستم اطلاع‌رسانی</a>
        <a href="logout.php" class="list-group-item list-group-item-action bg-dark text-white">خروج</a>
    </div>
</div>